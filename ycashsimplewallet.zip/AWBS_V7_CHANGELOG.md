# AWBS V7 — Ordered Parallel Crypto Scanner

- Reworked the production Sapling trial-decryption path in `yecshell-lib/src/lightwallet.rs`.
- Compact outputs are partitioned into 256-output crypto tiles and dispatched to the existing shared `ThreadPool`.
- Crypto work is submitted in bounded waves of at most 16 tiles, preventing the threadpool's unbounded queue from becoming a memory-pressure point on large blocks/ranges.
- Worker completion order is never used as wallet order: every result carries its canonical input offset and is reassembled into the original compact-output order.
- Commitment-tree insertion, witness updates, note materialisation, spend/change classification, wallet transaction creation, and wallet/database mutation remain on the existing sequential path.
- Prepared Sapling IVKs are shared across all crypto workers for the block rather than rebuilt per output.
- Legacy/non-canonical ciphertext fallback remains intact.
- Existing sequential matcher remains available for small blocks and the emergency `YCASH_DISABLE_BATCH_EC` switch.
- Existing parallel-vs-sequential regression coverage remains in the wallet test suite.
- No change to key serialization, transaction serialization, signature format, or verification behaviour.

## Target

This revision removes the previous crypto-path queueing limitation while preserving deterministic wallet state. It is an optimization, not a protocol change. Actual 15,000-block/sec performance must be established by native-device benchmarking.
