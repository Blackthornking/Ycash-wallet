class YcashConfig {
  static const ticker = 'YEC';
  static const coinType = 347;
  static const forkHeight = 570000;
  static const saplingActivationHeight = 419200;

  /// Canonical Ycash lightwalletd endpoint. All wallet sync/open paths use
  /// this endpoint so endpoint selection cannot silently drift between Dart
  /// and native code.
  static const lightwalletdServers = <String>[
    'https://lite.ycash.xyz:9067',
  ];

  /// Canonical endpoint for callers that just want "the" server.
  static const lightwalletd = 'https://lite.ycash.xyz:9067';

  /// Key under which the last endpoint that successfully opened the wallet is
  /// remembered.
  static const lastGoodServerKey = 'ycash.simple.lastServer';

  /// Best blocks/s ever observed, kept across launches so the figure is a
  /// record rather than a reading that resets every time the app restarts.
  static const bestBlocksPerSecKey = 'ycash.simple.bestBlocksPerSec';

  /// Selected colour scheme.
  static const themeKey = 'ycash.simple.theme';

  /// Private mode: shielded-only sends, auto-shielding of incoming
  /// transparent funds, transparent address hidden behind a warning.
  static const privateModeKey = 'ycash.simple.privateMode';

  /// Testnet. Coins here are worthless, which is the point.
  static const testnetKey = 'ycash.simple.testnet';

  /// Ycash's testnet lightwalletd, from zwallet's coin definition. Whether it
  /// is still running is not something the wallet can know in advance — a
  /// dead host surfaces as the usual connection failure.
  static const testnetServers = <String>[
    'https://testlite.ycash.xyz:9067',
  ];

  /// Testnet state is kept entirely apart from mainnet: its own seed entry,
  /// its own wallet directory, its own remembered server. Sharing either
  /// would risk showing a testnet balance while you believed it was real.
  static String seedKey(bool testnet) =>
      testnet ? 'ycash.simple.seed.testnet' : 'ycash.simple.seed';
  static String walletDirName(bool testnet) =>
      testnet ? 'ycash-simple-wallet-testnet' : 'ycash-simple-wallet';
  static String lastServerKey(bool testnet) =>
      testnet ? 'ycash.simple.lastServer.testnet' : lastGoodServerKey;
  static List<String> serversFor(bool testnet) =>
      testnet ? testnetServers : lightwalletdServers;

  /// Upper bound on a believable scan rate. Used to reject state jumps that
  /// are not measurements — notably a restored wallet's height being seeded
  /// to its birthday in one step — and to discard a record already poisoned
  /// by one. Real figures on a phone are in the low thousands.
  static const maxPlausibleBlocksPerSec = 50000.0;

  /// Raised from 512. Each batch costs a GetBlockRange round trip plus one
  /// GetTaddressTxids call per transparent address, and those fixed costs are
  /// paid once per batch regardless of size -- so on a multi-million-block
  /// catch-up a small batch multiplies connection overhead for no benefit.
  /// 2000 compact blocks is a few MB, well within a phone's budget.
  /// Block explorer. Ycash's public explorer; `txUrl` and `addressUrl` build
  /// the deep links used by the transaction detail screen and Settings.
  static const explorerBase = 'https://explorer.ycash.xyz';
  static String txUrl(String txid) => '$explorerBase/transaction/$txid';
  static String addressUrl(String address) => '$explorerBase/address/$address';

  static const modernBatchSize = 8000;
  static const modernWorkers = 8;

  /// AWBS tuning ladder. The controller may move between these practical
  /// targets as throughput allows, with 15,000 currently the hard ceiling.
  /// Keeping the ladder explicit makes it easy to raise the ceiling later
  /// without changing wallet serialization or scan semantics.
  static const awbsBatchSizes = <int>[
    1000, 2000, 4000, 6000, 8000, 10000, 12000, 15000,
  ];
  static const awbsMaxBatchSize = 15000;

  /// How often the UI re-reads native sync state. The native call takes the
  /// engine's global state lock, which the scanning thread also wants, so
  /// polling several times a second actively slows scanning down on a phone.
  static const statusPoll = Duration(seconds: 1);

  /// How often to kick off another sync round. The native engine returns as
  /// soon as it reaches the chain tip, so without this the wallet would sync
  /// once at open and then never see another block.
  static const resyncInterval = Duration(seconds: 30);

  /// Attempts (per server) when opening the wallet, with a short backoff.
  /// Opening does a live getinfo call, so a phone that has just come back
  /// onto a network can legitimately fail the first try.
  static const openAttempts = 2;
  static const openRetryDelay = Duration(seconds: 3);
}
