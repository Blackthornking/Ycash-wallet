import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:decimal/decimal.dart';
import '../core/auth.dart';
import '../core/config.dart';
import '../core/wallet.dart';
import '../design/tokens.dart';
import 'settings.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'history.dart';
import 'send.dart';
import '../core/privacy.dart';
import '../core/theme.dart';
import '../core/tx.dart';

class Home extends StatefulWidget {
  final SimpleWallet wallet;
  /// Called after the wallet has been wiped, so the app can drop back to
  /// onboarding. SimpleWallet.wipe() existed but was wired to nothing, which
  /// left clearing the app's storage in Android settings as the only way to
  /// start over -- awkward when a wallet has to be recreated between test
  /// builds.
  final VoidCallback onWiped;
  /// Called after the accent colour changes, so the app rebuilds under it.
  final Future<void> Function() onThemeChanged;
  final bool testnet;
  const Home({super.key,required this.wallet,required this.onWiped,
    required this.onThemeChanged,this.testnet=false});
  @override State<Home> createState()=>_HomeState();
}
class _HomeState extends State<Home>{
  StreamSubscription? sub; SimpleSyncStatus? sync; Map<String,dynamic>? bal; String? address; List<dynamic> history=[];
  List<WalletTx> txs=const [];
  /// Best blocks/s ever seen, persisted so it survives a restart.
  double bestBlocksPerSec=0;
  /// The wallet's transparent address. Only the shielded one was ever shown,
  /// so there was no way to check whether the t-address the wallet is
  /// actually watching matches the one that received a transparent payment.
  String? taddress;
  Timer? dataTimer;
  /// First block height seen this session, so the screen can show how far
  /// this wallet actually has to scan. A wallet seeded from the bundled
  /// checkpoint table starts around block 960,000; one seeded from the
  /// server's own tree state starts near the chain tip. Showing it makes
  /// which of the two happened obvious at a glance.
  int? startHeight;
  @override void initState(){
    super.initState();
    _refresh();
    _loadBest();
    PrivateMode.isEnabled().then((v){ if(mounted) setState(()=>privateMode=v); });
    sub=widget.wallet.status.stream.listen((s){
      if(!mounted)return;
      _recordBest(s.blocksPerSec);
      final wasSyncing=sync?.syncing??false;
      setState((){
        sync=s;
        if(startHeight==null && s.height>0) startHeight=s.height;
      });
      // Balances, addresses and history were previously read exactly once,
      // in initState, and then only again on a manual pull-to-refresh. So a
      // wallet could scan all the way to the chain tip in the background and
      // still show a zero balance and an empty history until the user
      // happened to swipe down. Refresh on the sync-finished edge.
      if(wasSyncing && !s.syncing) _refresh();
      _maybeAutoShield(s);
    });
    // And refresh periodically while a long initial scan is running, so
    // incoming transactions appear as they are found rather than only at the
    // very end of a multi-hour catch-up.
    dataTimer=Timer.periodic(const Duration(seconds:5),(_){ if((sync?.syncing??false)) _refresh(); });
  }
  @override void dispose(){sub?.cancel();dataTimer?.cancel();super.dispose();}
  /// True while a refresh is already in flight, so the 5-second timer cannot
  /// stack isolate spawns on a slow read.
  bool _refreshing=false;
  bool shielding=false;
  bool privateMode=false;
  DateTime? _lastAutoShield;

  /// Transparent balance in zatoshi.
  int get tBalance=>(bal?['tbalance'] as num?)?.toInt()??0;

  /// Sweep transparent funds into the shielded pool, unprompted.
  ///
  /// Rate-limited to once a minute regardless of what the balance does: if a
  /// shield fails for a reason that persists -- no proving parameters, a dead
  /// server -- retrying every second would spin the prover continuously and
  /// flatten the battery.
  Future<void> _reloadPrivacy() async {
    final v=await PrivateMode.isEnabled();
    if(mounted) setState(()=>privateMode=v);
  }

  Future<void> _maybeAutoShield(SimpleSyncStatus s) async {
    if(!PrivateMode.shouldAutoShield(
      enabled: privateMode,
      transparentZats: tBalance,
      caughtUp: s.tip>0 && s.height>=s.tip,
      busy: shielding,
    )) return;
    final last=_lastAutoShield;
    if(last!=null && DateTime.now().difference(last).inSeconds < 60) return;
    _lastAutoShield=DateTime.now();
    await _shieldAll(automatic:true);
  }

  Future<void> _shieldAll({bool automatic=false}) async {
    // In private mode this is the wallet doing what it promised, so it does
    // not stop to ask. Manual shielding still confirms.
    final ok=automatic?true:await showDialog<bool>(context:context,builder:(d)=>AlertDialog(
      title:const Text('Shield transparent funds'),
      content:Text('Move ${(tBalance/1e8).toStringAsFixed(8)} YEC from your '
        'transparent address into your shielded address, less the network fee.\n\n'
        'After this, the balance is private.'),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Shield')),
      ]));
    if(ok!=true||!mounted) return;
    setState(()=>shielding=true);
    widget.wallet.pausePolling();
    try{
      final tx=await widget.wallet.shieldAllAsync();
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content:Text(automatic?'Incoming funds shielded automatically':'Shielded: $tx')));
      }
      await _refresh();
    }catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('Shield failed: $e')));
      }
    }finally{
      widget.wallet.resumePolling();
      if(mounted) setState(()=>shielding=false);
    }
  }

  Future<void> _refresh() async {
    if(_refreshing) return;
    _refreshing=true;
    try{
      // Off the UI isolate. These three calls all take the native state lock,
      // which a send holds for the whole of proof generation -- doing them
      // here on the main thread stalled the UI for seconds and Android killed
      // the app mid-send.
      final snap=await widget.wallet.snapshotAsync();
      if(!mounted) return;
      bal=Map<String,dynamic>.from(snap['balances'] as Map);
      final addrs=Map<String,dynamic>.from(snap['addresses'] as Map);
      address=(addrs['z_addresses'] as List).first.toString();
      final t=addrs['t_addresses'] as List?;
      taddress=(t==null||t.isEmpty)?null:t.first.toString();
      history=List<dynamic>.from(snap['history'] as List);
      txs=WalletTx.parseAll(history);
    }catch(_){
    }finally{
      _refreshing=false;
    }
    if(mounted)setState((){});
  }
  /// Always keep the block numbers on screen.
  ///
  /// Previously the 'connecting' phase replaced them with just the server
  /// name -- but the engine re-enters that phase at the start of *every*
  /// sync round, including each automatic retry after a dropped connection.
  /// So a perfectly normal reconnect made the height and tip disappear and
  /// looked exactly like the scan had cut out and reset, when in fact it
  /// resumes from where it got to. The phase is now a prefix on the numbers
  /// rather than a replacement for them.
  String get _statusLine {
    final s=sync;
    if(s==null) return 'Connecting…';
    final pct=s.tip>0 ? ' (${(s.progress*100).toStringAsFixed(1)}%)' : '';
    final at=s.tip>0 ? '${s.height} / ${s.tip}$pct' : '${s.height}';
    // Caught up beats whatever phase the engine happens to be in. The resync
    // timer opens a new round every 30s, and each round passes through
    // Connecting before discovering there is nothing to fetch -- so at the
    // tip the label flickered to "Reconnecting" forever and looked stuck when
    // the wallet was in fact fully synced. Only a real error outranks this.
    if(s.tip>0 && s.height>=s.tip && s.phase!='error'){
      return 'Synced at ${s.height}';
    }
    switch(s.phase){
      case 'connecting':     return 'Reconnecting · $at';
      case 'scanning':       return 'Scanning $at';
      case 'fetching_memos': return 'Finishing up · $at';
      case 'error':          return 'Connection dropped, retrying · $at';
      default:               return s.height>0 ? 'Synced at ${s.height}' : 'Waiting to sync';
    }
  }
  double get total=>((bal?['spendable_zbalance'] as num?)?.toDouble()??0)/1e8+((bal?['tbalance'] as num?)?.toDouble()??0)/1e8;
  Future<void> _loadBest() async {
    try{
      final prefs=await SharedPreferences.getInstance();
      var v=prefs.getDouble(YcashConfig.bestBlocksPerSecKey) ?? 0;
      // Discard a record written before the sampler was fixed. A stored
      // 2,332,880 blocks/s came from a restored wallet's height being seeded
      // to its birthday in one poll, and it can never be beaten, so it would
      // sit there forever.
      if(v>YcashConfig.maxPlausibleBlocksPerSec){
        v=0;
        await prefs.remove(YcashConfig.bestBlocksPerSecKey);
      }
      if(mounted && v>bestBlocksPerSec) setState(()=>bestBlocksPerSec=v);
    }catch(_){}
  }

  /// Only writes when the record is actually beaten, so this is a handful of
  /// preference writes over the life of a sync rather than one per poll.
  Future<void> _recordBest(double rate) async {
    if(rate<=bestBlocksPerSec || rate<=0) return;
    if(rate>YcashConfig.maxPlausibleBlocksPerSec) return;
    setState(()=>bestBlocksPerSec=rate);
    try{
      final prefs=await SharedPreferences.getInstance();
      await prefs.setDouble(YcashConfig.bestBlocksPerSecKey,rate);
    }catch(_){}
  }

  void _openHistory(BuildContext c)=>Navigator.push(c,MaterialPageRoute(
    builder:(_)=>History(txs:txs,chainTip:sync?.tip??0)));

  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(
    titleSpacing:16,
    // The default 56px toolbar can't fit a 56px mark with any breathing room,
    // so the bar grows with it.
    toolbarHeight:76,
    title:Row(mainAxisSize:MainAxisSize.min,children:[
      // The mark is white-on-transparent, so it needs a dark disc behind it
      // to read as a logo rather than floating glyph strokes.
      Container(
        width:56,height:56,
        decoration:const BoxDecoration(color:Colors.black,shape:BoxShape.circle),
        padding:const EdgeInsets.all(5),
        child:Image.asset('assets/branding/yodl_logo.png',fit:BoxFit.contain),
      ),
      const SizedBox(width:10),
      const Text('Yodl',style:TextStyle(fontSize:26,fontWeight:FontWeight.w700)),
    ]),
    actions:[
      IconButton(onPressed:(){widget.wallet.startSync();},icon:const Icon(Icons.sync)),
      IconButton(
        tooltip:'Settings',
        icon:const Icon(Icons.settings),
        onPressed:()=>Navigator.push(c,MaterialPageRoute(
          builder:(_)=>Settings(wallet:widget.wallet,onWiped:widget.onWiped,
            onThemeChanged:widget.onThemeChanged))),
      ),
    ]),body:RefreshIndicator(onRefresh:()async{widget.wallet.startSync();await Future.delayed(const Duration(milliseconds:400));_refresh();},child:ListView(padding:const EdgeInsets.all(16),children:[
    // Hide the bar once caught up, for the same reason as the label: at the
    // tip the 30s resync briefly re-enters a syncing phase, which made a
    // full-width bar blink in and out on an idle wallet.
    if((sync?.syncing??false) && !((sync!.tip>0) && sync!.height>=sync!.tip))
      LinearProgressIndicator(value:sync!.progress),
    const SizedBox(height:16),
    // The balance sits on the page rather than inside a bordered card.
    // Boxing it made it one panel among several; the figure is the reason
    // the screen exists, so nothing competes with it for attention.
    // Testnet coins are worthless. This sits above the balance, spans the
    // full width and uses a colour no theme uses, because the failure mode
    // is someone believing a testnet balance is real money.
    if(widget.testnet)
      Container(
        width:double.infinity,
        margin:const EdgeInsets.only(bottom:4),
        padding:const EdgeInsets.symmetric(horizontal:14,vertical:9),
        decoration:BoxDecoration(
          color:const Color(0xFFF5A524).withValues(alpha:0.16),
          border:Border.all(color:const Color(0xFFF5A524)),
          borderRadius:BorderRadius.circular(12)),
        child:Row(children:[
          const Icon(Icons.science_outlined,size:16,color:Color(0xFFF5A524)),
          const SizedBox(width:8),
          const Expanded(child:Text('Test mode — these coins are not real',
            style:TextStyle(fontSize:12,fontWeight:FontWeight.w600,
              color:Color(0xFFF5A524)))),
        ])),
    Padding(padding:const EdgeInsets.fromLTRB(8,18,8,0),child:Column(
      crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(mainAxisAlignment:MainAxisAlignment.center,
        crossAxisAlignment:CrossAxisAlignment.center,children:[
        Padding(
          padding:const EdgeInsets.only(right:8),
          child:Image.asset('assets/branding/yec_symbol.png',
            height:40,fit:BoxFit.contain,
            color:Theme.of(c).textTheme.bodyLarge?.color),
        ),
        Flexible(child:FittedBox(fit:BoxFit.scaleDown,
          // Tabular figures: the balance changes while you are looking at it,
          // and proportional digits make the decimal point wander.
          child:Text(total.toStringAsFixed(3),
            style:YodlTheme.figures(size:48,weight:FontWeight.w800)))),
      ]),
      const SizedBox(height:14),
      Center(child:GestureDetector(
        onTap:()=>Navigator.push(c,MaterialPageRoute(
          builder:(_)=>Settings(wallet:widget.wallet,onWiped:widget.onWiped,
            onThemeChanged:widget.onThemeChanged))).then((_)=>_reloadPrivacy()),
        child:Container(
          padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),
          decoration:BoxDecoration(
            borderRadius:BorderRadius.circular(999),
            color:privateMode
              ? Theme.of(c).colorScheme.primary.withValues(alpha:0.16)
              : Colors.transparent,
            border:Border.all(color:privateMode
              ? Theme.of(c).colorScheme.primary
              : Theme.of(c).dividerColor)),
          child:Row(mainAxisSize:MainAxisSize.min,children:[
            Icon(privateMode?Icons.shield:Icons.shield_outlined,size:13,
              color:privateMode
                ? Theme.of(c).colorScheme.primary
                : Theme.of(c).hintColor),
            const SizedBox(width:6),
            Text(privateMode?'Private mode on':'Private mode off',
              style:TextStyle(fontSize:12,
                color:privateMode
                  ? Theme.of(c).colorScheme.primary
                  : Theme.of(c).hintColor)),
          ])))),
      const SizedBox(height:12),
      Center(child:Text(_statusLine,
        style:TextStyle(fontSize:13,color:Theme.of(c).hintColor))),
      if((sync?.transparentWarning??'').isNotEmpty)
        Padding(padding:const EdgeInsets.only(top:8),child:Text(sync!.transparentWarning,style:const TextStyle(color:Colors.amber,fontSize:12))),
      if(sync?.saveError!=null)
        Padding(padding:const EdgeInsets.only(top:8),child:Text('Could not save progress: ${sync!.saveError}',style:const TextStyle(color:YColors.danger,fontSize:12))),
      if(sync?.error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(sync!.error!,style:const TextStyle(color:YColors.danger))),
    ])),
    const SizedBox(height:16),
    Row(children:[
      Expanded(child:_ActionTile(icon:Icons.arrow_upward,label:'Send',primary:true,
        onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Send(wallet:widget.wallet))))),
      const SizedBox(width:10),
      Expanded(child:_ActionTile(icon:Icons.qr_code,label:'Receive',
        onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Receive(
          address:address??'',taddress:taddress,privateMode:privateMode))))),
      const SizedBox(width:10),
      Expanded(child:_ActionTile(icon:Icons.history,label:'History',
        onTap:()=>_openHistory(c))),
    ]),
    // Transparent funds are publicly linkable; shielding them is the single
    // most useful action a Ycash wallet can offer, so it sits in front of you
    // whenever there is a transparent balance rather than behind a menu.
    if(tBalance>0) ...[
      const SizedBox(height:20),
      Container(
        padding:const EdgeInsets.fromLTRB(14,8,8,8),
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(20),
          border:Border.all(color:Theme.of(c).colorScheme.primary.withValues(alpha:0.45)),
          color:Theme.of(c).colorScheme.primary.withValues(alpha:0.08)),
        child:Row(children:[
          Text('Transparent balance',
            style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
          const SizedBox(width:10),
          Expanded(child:Text((tBalance/1e8).toStringAsFixed(8),
            style:YodlTheme.figures(size:14,weight:FontWeight.w600))),
          const SizedBox(width:8),
          if(privateMode)
            Text(shielding?'Shielding…':'Auto',
              style:TextStyle(fontSize:12,color:Theme.of(c).colorScheme.primary))
          else
            FilledButton(
              onPressed:shielding?null:_shieldAll,
              style:FilledButton.styleFrom(
                visualDensity:VisualDensity.compact,
                padding:const EdgeInsets.symmetric(horizontal:16)),
              child:Text(shielding?'Shielding…':'Shield')),
        ])),
    ],
    const SizedBox(height:24),
    Row(children:[
      const Expanded(child:Text('Recent activity',style:TextStyle(fontSize:18,fontWeight:FontWeight.w700))),
      if(txs.length>5) TextButton(onPressed:()=>_openHistory(c),child:const Text('See all')),
    ]),
    if(txs.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('No transactions yet.',textAlign:TextAlign.center))
    else ...txs.take(5).map((t)=>TxRow(tx:t,chainTip:sync?.tip??0)),
    // Engine/server detail lives in Settings > Scanner statistics now; it
    // was crowding the bottom bar and is not something to read every day.
    const SizedBox(height:16),
  ])),
  // Bottom bar mirrors the same destinations as the action row. Home is the
  // screen you are on, so tapping it just scrolls nothing -- the others push.
  bottomNavigationBar:NavigationBar(
    selectedIndex:0,
    onDestinationSelected:(i){
      switch(i){
        case 1: Navigator.push(c,MaterialPageRoute(builder:(_)=>Send(wallet:widget.wallet))); break;
        case 2: Navigator.push(c,MaterialPageRoute(builder:(_)=>Receive(
          address:address??'',taddress:taddress,privateMode:privateMode))); break;
        case 3: _openHistory(c); break;
        case 4: Navigator.push(c,MaterialPageRoute(builder:(_)=>Settings(wallet:widget.wallet,onWiped:widget.onWiped,onThemeChanged:widget.onThemeChanged))); break;
      }
    },
    destinations:const [
      NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
      NavigationDestination(icon:Icon(Icons.send_outlined),label:'Send'),
      NavigationDestination(icon:Icon(Icons.qr_code),label:'Receive'),
      NavigationDestination(icon:Icon(Icons.history),label:'History'),
      NavigationDestination(icon:Icon(Icons.settings_outlined),label:'Settings'),
    ]),
  );
}

/// Square-ish action tile: icon above label, stacked rather than inline.
///
/// The previous row put an icon and text side by side inside a pill, which
/// left "Receive" and "History" fighting for width on a narrow phone and
/// ellipsising. Stacking gives the label the full tile width, and a fixed
/// aspect keeps the three tiles square and identical regardless of how long
/// the words are.
class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool primary;
  final VoidCallback onTap;
  const _ActionTile({required this.icon,required this.label,required this.onTap,this.primary=false});

  @override Widget build(BuildContext c){
    final scheme=Theme.of(c).colorScheme;
    final bg=primary?scheme.primary:scheme.surfaceContainerHighest;
    final fg=primary?scheme.onPrimary:scheme.onSurface;
    return AspectRatio(
      aspectRatio:1,
      child:Material(
        color:bg,
        borderRadius:BorderRadius.circular(22),
        child:InkWell(
          borderRadius:BorderRadius.circular(22),
          onTap:onTap,
          child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
            Icon(icon,color:fg,size:26),
            const SizedBox(height:10),
            Padding(
              padding:const EdgeInsets.symmetric(horizontal:6),
              child:FittedBox(fit:BoxFit.scaleDown,
                child:Text(label,style:TextStyle(
                  color:fg,fontSize:15,fontWeight:FontWeight.w600))),
            ),
          ]),
        ),
      ));
  }
}

/// Receive screen: one card per address type, each opening its own QR.
///
/// Ycash wallets have two unrelated addresses and they are not
/// interchangeable. Shielded (ys1...) is a Sapling address; transparent
/// (s1...) is a Bitcoin-style P2PKH address. A sender must use the one that
/// matches what they are sending to, and only showing the shielded one meant
/// there was no way to check which transparent address this wallet is
/// actually watching.
class Receive extends StatelessWidget {
  final String address;
  final String? taddress;
  final bool privateMode;
  const Receive({super.key,required this.address,this.taddress,this.privateMode=false});

  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('Receive')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      _AddressCard(
        title:'Shielded address',
        subtitle:'Private. Amounts and memos are hidden on chain.',
        address:address,
      ),
      const SizedBox(height:16),
      // In private mode the transparent address is behind a disclosure
      // rather than presented as an equal option. It is not removed --
      // some exchanges still refuse to send to a shielded address, and
      // hiding it entirely would strand people.
      if(privateMode)
        Theme(
          data:Theme.of(c).copyWith(dividerColor:Colors.transparent),
          child:ExpansionTile(
            tilePadding:EdgeInsets.zero,
            title:const Text('Need a transparent address?',
              style:TextStyle(fontSize:14,fontWeight:FontWeight.w600)),
            subtitle:Text('Public. Anyone can see payments to it.',
              style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
            children:[
              Padding(
                padding:const EdgeInsets.only(bottom:12),
                child:Text(
                  'A payment to this address is permanently visible on the '
                  'block explorer, along with the amount and the sender. '
                  'Private mode will shield anything that arrives here, but '
                  'that hides where the money goes next — not where it came '
                  'from.',
                  style:TextStyle(fontSize:12,height:1.5,color:Theme.of(c).hintColor)),
              ),
              _AddressCard(
                title:'Transparent address',
                subtitle:'Public, like a Bitcoin address.',
                address:taddress??'',
              ),
            ])),
      if(!privateMode)
      _AddressCard(
        title:'Transparent address',
        subtitle:'Public, like a Bitcoin address. Visible on the block explorer.',
        address:taddress??'',
      ),
    ]));
}

class _AddressCard extends StatelessWidget {
  final String title,subtitle,address;
  const _AddressCard({required this.title,required this.subtitle,required this.address});

  @override Widget build(BuildContext c){
    final has=address.isNotEmpty;
    return Container(
      padding:const EdgeInsets.all(18),
      decoration:BoxDecoration(
        border:Border.all(color:Theme.of(c).dividerColor),
        borderRadius:BorderRadius.circular(18),
      ),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w700)),
        const SizedBox(height:4),
        Text(subtitle,style:TextStyle(fontSize:12,color:Theme.of(c).hintColor)),
        const SizedBox(height:14),
        if(!has)
          Text('Not available yet — still loading.',style:TextStyle(color:Theme.of(c).hintColor))
        else ...[
          SelectableText(address,style:const TextStyle(fontFamily:'monospace',fontSize:13)),
          const SizedBox(height:14),
          Row(children:[
            Expanded(child:FilledButton.icon(
              onPressed:()=>Navigator.push(c,MaterialPageRoute(
                builder:(_)=>_QrScreen(title:title,address:address))),
              icon:const Icon(Icons.qr_code,size:18),
              label:const Text('QR code'))),
            const SizedBox(width:8),
            IconButton(
              tooltip:'Copy',
              onPressed:(){
                Clipboard.setData(ClipboardData(text:address));
                ScaffoldMessenger.of(c).showSnackBar(
                  SnackBar(content:Text('$title copied')));
              },
              icon:const Icon(Icons.copy)),
            IconButton(
              tooltip:'Share',
              onPressed:()=>Share.share(address),
              icon:const Icon(Icons.ios_share)),
          ]),
        ],
      ]));
  }
}

class _QrScreen extends StatelessWidget {
  final String title,address;
  const _QrScreen({required this.title,required this.address});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:Text(title)),
    body:ListView(padding:const EdgeInsets.all(24),children:[
      Center(child:Container(
        padding:const EdgeInsets.all(16),
        color:Colors.white,
        child:QrImageView(data:address,size:260))),
      const SizedBox(height:24),
      SelectableText(address,textAlign:TextAlign.center,
        style:const TextStyle(fontFamily:'monospace',fontSize:13)),
      const SizedBox(height:20),
      Row(children:[
        Expanded(child:OutlinedButton.icon(
          onPressed:(){
            Clipboard.setData(ClipboardData(text:address));
            ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Copied')));
          },
          icon:const Icon(Icons.copy,size:18),label:const Text('Copy'))),
        const SizedBox(width:10),
        Expanded(child:OutlinedButton.icon(
          onPressed:()=>Share.share(address),
          icon:const Icon(Icons.ios_share,size:18),label:const Text('Share'))),
      ]),
    ]));
}
