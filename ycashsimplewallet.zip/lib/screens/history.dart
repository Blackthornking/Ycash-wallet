import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/tx.dart';

String _fmtAmount(WalletTx t) {
  final sign = t.incoming ? '+' : '';
  return '$sign${t.yec.toStringAsFixed(8)}';
}

String _shortId(String txid) =>
    txid.length <= 20 ? txid : '${txid.substring(0, 8)}…${txid.substring(txid.length - 8)}';

const _months = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY',
                 'AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];

String _dayHeader(DateTime d) => '${_months[d.month - 1]} ${d.day}';
String _hhmm(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

Future<void> _open(BuildContext c, String url) async {
  final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  if (!ok && c.mounted) {
    ScaffoldMessenger.of(c).showSnackBar(
      SnackBar(content: Text('Could not open $url')));
  }
}

/// Full transaction history.
class History extends StatelessWidget {
  final List<WalletTx> txs;
  final int chainTip;
  const History({super.key, required this.txs, required this.chainTip});

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('History')),
    body: txs.isEmpty
      ? const Center(child: Padding(padding: EdgeInsets.all(32),
          child: Text('No transactions yet.', textAlign: TextAlign.center)))
      : ListView(padding: const EdgeInsets.symmetric(vertical: 8),
          children: _grouped(c)),
  );

  List<Widget> _grouped(BuildContext c) {
    final out = <Widget>[];
    String? lastHeader;
    for (final t in txs) {
      final header = t.pending ? 'PENDING' : _dayHeader(t.time);
      if (header != lastHeader) {
        out.add(Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
          child: Text(header, style: TextStyle(
            fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.w700,
            color: Theme.of(c).hintColor)),
        ));
        lastHeader = header;
      }
      out.add(TxRow(tx: t, chainTip: chainTip));
    }
    return out;
  }
}

/// A single line in the history or on the home screen.
class TxRow extends StatelessWidget {
  final WalletTx tx;
  final int chainTip;
  const TxRow({super.key, required this.tx, required this.chainTip});

  @override
  Widget build(BuildContext c) => ListTile(
    onTap: () => Navigator.push(c, MaterialPageRoute(
      builder: (_) => TxDetail(tx: tx, chainTip: chainTip))),
    leading: CircleAvatar(
      backgroundColor: Theme.of(c).colorScheme.surfaceContainerHighest,
      child: Icon(tx.incoming ? Icons.south_west : Icons.north_east,
        size: 20,
        color: tx.incoming ? Colors.greenAccent : Theme.of(c).colorScheme.onSurface),
    ),
    title: Text(tx.incoming ? 'Received YEC' : 'Sent YEC',
      style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Text(_shortId(tx.txid),
      style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
    trailing: Column(mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(_fmtAmount(tx), style: TextStyle(fontWeight: FontWeight.w700,
          color: tx.incoming ? Colors.greenAccent : null)),
        Text(tx.pending ? 'pending' : _hhmm(tx.time),
          style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
      ]),
  );
}

/// Everything known about one transaction.
class TxDetail extends StatelessWidget {
  final WalletTx tx;
  final int chainTip;
  const TxDetail({super.key, required this.tx, required this.chainTip});

  @override
  Widget build(BuildContext c) {
    final confirmations = tx.confirmations(chainTip);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction details'),
        // No explorer icon here: the single link is the button at the bottom
        // of the page. Three ways to reach the same URL made the page look
        // like it offered three different destinations.
        ),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const SizedBox(height: 8),
        Center(child: Text(
          tx.incoming ? 'AMOUNT RECEIVED' : 'AMOUNT SENT',
          style: TextStyle(fontSize: 11, letterSpacing: 1.6,
            fontWeight: FontWeight.w700, color: Theme.of(c).hintColor))),
        const SizedBox(height: 12),
        Center(child: FittedBox(fit: BoxFit.scaleDown, child: Row(
          mainAxisSize: MainAxisSize.min, children: [
            Padding(padding: const EdgeInsets.only(right: 8),
              child: Image.asset('assets/branding/yec_symbol.png', height: 22,
                color: Theme.of(c).textTheme.bodyLarge?.color)),
            Text(_fmtAmount(tx), style: const TextStyle(
              fontSize: 32, fontWeight: FontWeight.w700)),
          ]))),
        const SizedBox(height: 16),
        Center(child: _StatusPill(pending: tx.pending, confirmations: confirmations)),
        const SizedBox(height: 28),

        _Card(children: [
          _Field('Transaction ID', _shortId(tx.txid), copy: tx.txid),
          _Split(
            left: _Field('Block height', tx.pending ? '—' : '#${tx.blockHeight}'),
            right: _Field('Confirmations', tx.pending ? '0' : '$confirmations'),
          ),
          _Split(
            left: _Field('Timestamp', tx.pending ? 'Pending'
              : '${tx.time.day}/${tx.time.month}/${tx.time.year} • ${_hhmm(tx.time)}'),
            right: _Field('Type', tx.transparent ? 'Transparent'
              : tx.shielded ? 'Shielded' : 'Unknown'),
          ),
        ]),

        if (tx.address != null) ...[
          const SizedBox(height: 12),
          _Card(children: [
            _Field(tx.incoming ? 'Received at' : 'Sent to', tx.address!,
              copy: tx.address),
          ]),
        ],

        const SizedBox(height: 12),
        _Card(children: [
          _Field('Memo', tx.memo ?? (tx.transparent
            ? 'Transparent transactions cannot carry a memo'
            : 'No memo')),
        ]),

        if (tx.transparent) ...[
          const SizedBox(height: 20),
          // Transparent transactions are fully public, so the explorer is the
          // authoritative record: inputs, outputs, fee and confirmations that
          // this wallet does not track locally.
          OutlinedButton.icon(
            onPressed: () => _open(c, tx.explorerUrl),
            icon: const Icon(Icons.open_in_new, size: 18),
            label: const Text('View on block explorer')),
        ] else ...[
          const SizedBox(height: 20),
          Text(
            'This is a shielded transaction. Its amount, addresses and memo are '
            'encrypted on chain, so a block explorer cannot show them.',
            style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
        ],
        const SizedBox(height: 32),
      ]));
  }
}

class _StatusPill extends StatelessWidget {
  final bool pending;
  final int confirmations;
  const _StatusPill({required this.pending, required this.confirmations});

  @override
  Widget build(BuildContext c) {
    // Ycash inherits Zcash's block timing; 10 confirmations is the usual point
    // at which a payment is treated as settled rather than merely mined.
    final settled = !pending && confirmations >= 10;
    final label = pending ? 'PENDING'
      : settled ? 'CONFIRMED'
      : 'CONFIRMING ($confirmations)';
    final colour = pending ? Colors.amber
      : settled ? Colors.greenAccent
      : Colors.lightBlueAccent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
      decoration: BoxDecoration(
        color: colour.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: colour.withValues(alpha: 0.5))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.circle, size: 9, color: colour),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(
          color: colour, fontWeight: FontWeight.w700, letterSpacing: 0.6)),
      ]));
  }
}

class _Card extends StatelessWidget {
  final List<Widget> children;
  const _Card({required this.children});
  @override
  Widget build(BuildContext c) => Container(
    decoration: BoxDecoration(
      border: Border.all(color: Theme.of(c).dividerColor),
      borderRadius: BorderRadius.circular(16)),
    child: Column(children: children));
}

class _Split extends StatelessWidget {
  final Widget left, right;
  const _Split({required this.left, required this.right});
  @override
  Widget build(BuildContext c) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [Expanded(child: left), Expanded(child: right)]);
}

class _Field extends StatelessWidget {
  final String label, value;
  final String? copy;
  const _Field(this.label, this.value, {this.copy});

  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label.toUpperCase(), style: TextStyle(
        fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w700,
        color: Theme.of(c).hintColor)),
      const SizedBox(height: 6),
      Row(children: [
        Expanded(child: SelectableText(value,
          style: const TextStyle(fontSize: 13))),
        if (copy != null)
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.copy, size: 16),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: copy!));
              ScaffoldMessenger.of(c).showSnackBar(
                SnackBar(content: Text('$label copied')));
            }),
      ]),
    ]));
}
