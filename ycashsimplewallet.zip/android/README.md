# Android host

The Android host is regenerated from the installed Flutter SDK in CI before building:

```bash
flutter create --platforms=android --org com.ycashfoundation .
```

This keeps the project on the current supported Flutter Android embedding and generates
matching Gradle/Android Gradle Plugin wrapper files. Custom wallet code lives in Dart and
`packages/ycash_core_ffi`; do not copy obsolete Android v1 embedding files back into this project.
