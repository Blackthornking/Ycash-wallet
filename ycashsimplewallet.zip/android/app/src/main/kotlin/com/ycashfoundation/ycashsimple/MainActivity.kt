package com.ycashfoundation.ycashsimple

// FlutterFragmentActivity, not FlutterActivity: local_auth shows the system
// BiometricPrompt, which is a Fragment and requires a FragmentActivity host.
// With a plain FlutterActivity the prompt throws "no_fragment_activity" at
// runtime instead of failing at build time.
import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity : FlutterFragmentActivity()
