package quantum_vault

// Package quantum_vault defines the versioned boundary for wallet secret-at-rest
// protection. The blockchain transaction and signature formats are intentionally
// outside this package.
const Version = 1
const Cipher = "AES-256-GCM"
