# YCash Sapling proving/signing integration

This package adds a real native integration boundary to the YCash upstream
`librustzcash` C ABI:

- `librustzcash_sapling_proving_ctx_init`
- `librustzcash_sapling_spend_proof`
- `librustzcash_sapling_output_proof`
- `librustzcash_sapling_spend_sig`
- `librustzcash_sapling_binding_sig`

## Important

The upstream ABI declarations are not enough by themselves to safely construct
a transaction. A production transaction builder must provide:

1. authenticated note and witness data;
2. consensus-correct anchor;
3. randomized spend authorization key material;
4. canonical transaction sighash;
5. value balance accounting;
6. YCash transaction serialization.

The Flutter layer must never create these cryptographic values itself.

## Linkage

Build the supplied `ycash-master` Rust static library for each Android ABI and
link it into `libycash_core.so`. Enable:

```text
--features ycash-sapling-ffi
```

The final linker configuration must be generated per target rather than
hard-coding a host library.

## Release gate

Do not enable mainnet spending until:
- spend proofs verify independently;
- output proofs verify independently;
- spend authorization signatures verify;
- binding signatures verify;
- serialized transactions are accepted by a YCash node;
- testnet/regtest integration tests cover rejection paths.
