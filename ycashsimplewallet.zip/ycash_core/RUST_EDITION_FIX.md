# Rust edition compatibility fix

`ycash_core` uses an existing C ABI boundary with `extern "C"` declarations and
`#[no_mangle]` exports. Rust 2024 makes several of these constructs require new
unsafe syntax. The wallet's FFI source was written using Rust 2021 semantics, so
this crate is intentionally built with `edition = "2021"`.

This changes language-edition checking only; it does not change the YCash
Sapling ABI, cryptographic code, transaction format, or wallet behavior.
