#!/usr/bin/env sh
set -eu

grep -q 'zcash/orchard.git' Cargo.toml
grep -q '648ef342' Cargo.toml
grep -q 'zcash/halo2.git' Cargo.toml
grep -q 'halo2_gadgets-0.4.0' Cargo.toml
grep -q 'halo2_gadgets = { git = "https://github.com/zcash/halo2.git"' Cargo.toml
grep -q 'halo2_proofs = { git = "https://github.com/zcash/halo2.git"' Cargo.toml
grep -q 'core2 = { path = "vendor/core2-shim" }' Cargo.toml
test -f vendor/core2-shim/Cargo.toml
test -f vendor/core2-shim/src/lib.rs
grep -q '^name = "core2"' vendor/core2-shim/Cargo.toml
grep -q '^version = "0.3.3"' vendor/core2-shim/Cargo.toml
grep -q 'pub use corez::\*;' vendor/core2-shim/src/lib.rs

echo 'Yanked Orchard/core2/halo2 recovery configuration: OK'
