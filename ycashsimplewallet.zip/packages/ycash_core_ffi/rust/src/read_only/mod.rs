//! Phase 57 read-only Ycash backend boundary.
//!
//! This module deliberately separates *address derivation* from display logic.
//! A production implementation must use the pinned Ycash forks and deterministic
//! vectors; syntactic address construction is never accepted as proof of ownership.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum ReadOnlyError {
    #[error("wallet is not open")]
    WalletClosed,
    #[error("verified Ycash address backend is not linked in this build")]
    BackendUnavailable,
}

pub fn shielded_address(_mnemonic: &str) -> Result<String, ReadOnlyError> {
    // IMPORTANT: Do not invent a ys1 address from an HRP change. The Sapling key
    // derivation and encoding must come from the pinned Ycash implementation.
    Err(ReadOnlyError::BackendUnavailable)
}

pub fn transparent_address(_mnemonic: &str) -> Result<String, ReadOnlyError> {
    // IMPORTANT: Do not guess Ycash Base58 prefixes. The canonical Ycash upstream
    // key/address implementation and deterministic vectors are required.
    Err(ReadOnlyError::BackendUnavailable)
}
