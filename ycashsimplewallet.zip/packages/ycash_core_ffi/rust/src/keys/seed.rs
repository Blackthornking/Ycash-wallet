use bip39::{Language, Mnemonic};
use rand::rngs::OsRng;
use zeroize::Zeroizing;
use crate::wallet::WalletError;

#[derive(Clone)]
pub struct WalletMnemonic(pub Zeroizing<String>);

pub struct SeedMaterial(pub Zeroizing<Vec<u8>>);

impl WalletMnemonic {
    pub fn generate_24() -> Result<(Self, SeedMaterial), WalletError> {
        let mnemonic = Mnemonic::generate_in_with(&mut OsRng, Language::English, 24)
            .map_err(|e| WalletError::Crypto(e.to_string()))?;
        let seed = mnemonic.to_seed("");
        Ok((Self(Zeroizing::new(mnemonic.to_string())), SeedMaterial(Zeroizing::new(seed.to_vec()))))
    }

    pub fn restore(phrase: &str, passphrase: &str) -> Result<(Self, SeedMaterial), WalletError> {
        let mnemonic = Mnemonic::parse_in_normalized(Language::English, phrase)
            .map_err(|e| WalletError::InvalidMnemonic(e.to_string()))?;
        let seed = mnemonic.to_seed(passphrase);
        Ok((Self(Zeroizing::new(mnemonic.to_string())), SeedMaterial(Zeroizing::new(seed.to_vec()))))
    }

    pub fn expose_for_backup(&self) -> &str { &self.0 }
}
