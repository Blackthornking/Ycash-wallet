use rusqlite::{params, Connection};
use crate::wallet::WalletError;

pub const SCHEMA_VERSION: i64 = 4;

pub fn open(path: &str) -> Result<Connection, WalletError> {
    let conn = Connection::open(path).map_err(|e| WalletError::Storage(e.to_string()))?;
    conn.busy_timeout(std::time::Duration::from_secs(2))
        .map_err(|e| WalletError::Storage(e.to_string()))?;
    // WAL keeps readers from blocking the writer during sync. FULL remains in
    // force so this is a concurrency optimization, not a durability downgrade.
    conn.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;")
        .map_err(|e| WalletError::Storage(e.to_string()))?;
    migrate(&conn)?;
    Ok(conn)
}

pub fn migrate(conn: &Connection) -> Result<(), WalletError> {
    conn.execute_batch("\
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY, birthday_height INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS transactions (txid TEXT PRIMARY KEY, height INTEGER, raw BLOB);
        CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL, value INTEGER NOT NULL, spent INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(account_id) REFERENCES accounts(id));
        CREATE TABLE IF NOT EXISTS scan_state (id INTEGER PRIMARY KEY CHECK(id=1), scanned_height INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS nullifiers (nullifier TEXT PRIMARY KEY, height INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS tx_history (txid TEXT PRIMARY KEY, height INTEGER, value_delta INTEGER NOT NULL, status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sapling_note_material (note_id TEXT PRIMARY KEY, diversifier BLOB NOT NULL, pk_d BLOB NOT NULL, rcm BLOB NOT NULL, witness_v2 BLOB NOT NULL, FOREIGN KEY(note_id) REFERENCES authenticated_notes(note_id));
        CREATE TABLE IF NOT EXISTS authenticated_notes (note_id TEXT PRIMARY KEY, account_id INTEGER NOT NULL, value INTEGER NOT NULL, position INTEGER NOT NULL, note_commitment BLOB NOT NULL, anchor BLOB NOT NULL, witness BLOB NOT NULL, spending_key_handle TEXT NOT NULL, spent INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(account_id) REFERENCES accounts(id));
        CREATE INDEX IF NOT EXISTS idx_notes_account_spent ON notes(account_id, spent);
        CREATE INDEX IF NOT EXISTS idx_authenticated_notes_account_spent ON authenticated_notes(account_id, spent);
        CREATE INDEX IF NOT EXISTS idx_authenticated_notes_position ON authenticated_notes(position);
        CREATE INDEX IF NOT EXISTS idx_nullifiers_height ON nullifiers(height);
        CREATE INDEX IF NOT EXISTS idx_tx_history_height ON tx_history(height);
    ").map_err(|e| WalletError::Storage(e.to_string()))?;
    conn.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES('schema_version', ?1)", params![SCHEMA_VERSION.to_string()])
        .map_err(|e| WalletError::Storage(e.to_string()))?;
    Ok(())
}
