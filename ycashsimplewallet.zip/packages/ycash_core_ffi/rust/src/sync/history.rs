use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum TransactionStatus { Pending, Confirmed, Reorged }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WalletTransaction {
    pub txid: String,
    pub height: Option<u32>,
    pub value_delta: i64,
    pub status: TransactionStatus,
}

#[derive(Debug, Default)]
pub struct TransactionHistory {
    entries: Vec<WalletTransaction>,
    index: HashMap<String, usize>,
}

impl TransactionHistory {
    pub fn upsert(&mut self, tx: WalletTransaction) {
        if let Some(&pos) = self.index.get(&tx.txid) {
            self.entries[pos] = tx;
        } else {
            let pos = self.entries.len();
            self.index.insert(tx.txid.clone(), pos);
            self.entries.push(tx);
        }
        self.entries.sort_by_key(|e| e.height.unwrap_or(u32::MAX));
        // Sorting changes positions; rebuild the tiny index so future upserts
        // remain O(1) lookup rather than O(n) linear scans.
        self.index.clear();
        for (i, e) in self.entries.iter().enumerate() { self.index.insert(e.txid.clone(), i); }
    }
    pub fn entries(&self) -> &[WalletTransaction] { &self.entries }
    pub fn rewind_to(&mut self, height: u32) {
        for tx in &mut self.entries {
            if tx.height.is_some_and(|h| h > height) { tx.status = TransactionStatus::Reorged; tx.height = None; }
        }
        self.index.clear();
        for (i, e) in self.entries.iter().enumerate() { self.index.insert(e.txid.clone(), i); }
    }
}
