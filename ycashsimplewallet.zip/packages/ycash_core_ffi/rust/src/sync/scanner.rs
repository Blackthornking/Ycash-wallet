//! Wallet scanner state machine. Cryptographic note trial-decryption is supplied
//! by the pinned Ycash Sapling backend.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScanRange { pub start: u32, pub end: u32 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScanProgress {
    pub height: u32,
    pub target_height: u32,
    pub discovered_notes: u64,
    pub discovered_spends: u64,
}

impl ScanProgress {
    pub fn fraction(&self) -> f64 {
        if self.target_height == 0 { return 0.0; }
        (self.height as f64 / self.target_height as f64).clamp(0.0, 1.0)
    }
}
