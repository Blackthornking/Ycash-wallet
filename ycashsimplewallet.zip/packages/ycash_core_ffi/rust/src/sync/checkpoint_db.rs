//! Lightweight durable AWBS sync checkpoint index.
//!
//! The wallet file remains the source of truth for wallet state. This SQLite
//! index is only a recovery/progress index and is advanced *after* the wallet
//! has been durably persisted. That ordering prevents the index from ever
//! claiming a height that the wallet file does not contain.

use rusqlite::{params, Connection, OptionalExtension};
use std::fs;
use std::path::{Path, PathBuf};

const DB_FILENAME: &str = "awbs_sync.sqlite";
const SCHEMA_VERSION: i64 = 1;

fn db_path(data_dir: &str) -> PathBuf {
    Path::new(data_dir).join(DB_FILENAME)
}

fn open(data_dir: &str) -> Result<Connection, String> {
    fs::create_dir_all(data_dir).map_err(|e| format!("cannot create sync index directory: {}", e))?;
    let conn = Connection::open(db_path(data_dir))
        .map_err(|e| format!("cannot open AWBS sync index: {}", e))?;
    conn.busy_timeout(std::time::Duration::from_secs(2))
        .map_err(|e| format!("cannot configure AWBS sync index: {}", e))?;
    conn.execute_batch(
        "PRAGMA journal_mode=WAL;
         PRAGMA synchronous=FULL;
         CREATE TABLE IF NOT EXISTS metadata (
             key TEXT PRIMARY KEY NOT NULL,
             value TEXT NOT NULL
         );
         CREATE TABLE IF NOT EXISTS checkpoints (
             id INTEGER PRIMARY KEY CHECK (id = 1),
             height INTEGER NOT NULL,
             updated_at INTEGER NOT NULL
         );
         INSERT OR REPLACE INTO metadata(key,value) VALUES('schema_version','1');",
    ).map_err(|e| format!("cannot initialize AWBS sync index: {}", e))?;
    Ok(conn)
}

/// Read the last height whose wallet state was durably persisted.
pub fn load(data_dir: &str) -> Result<Option<u64>, String> {
    let conn = open(data_dir)?;
    // `row.get(0)` has to be annotated: the column is stored as TEXT and is
    // then `.parse()`d into the i64 this binding declares, so nothing in the
    // expression pins down the intermediate type and inference gives up
    // (E0282). The value read here is the String; the parse produces the i64.
    let version: Option<i64> = conn.query_row(
        "SELECT value FROM metadata WHERE key='schema_version'",
        [],
        |row| row.get::<_, String>(0),
    ).optional().map_err(|e| format!("cannot read AWBS sync index version: {}", e))?
      .and_then(|v| v.parse().ok());
    if version != Some(SCHEMA_VERSION) {
        return Err("unsupported AWBS sync index schema".to_string());
    }
    conn.query_row("SELECT height FROM checkpoints WHERE id=1", [], |row| row.get::<_, i64>(0))
        .optional()
        .map_err(|e| format!("cannot read AWBS checkpoint: {}", e))
        .and_then(|v| v.map(|h| u64::try_from(h).map_err(|_| "invalid negative AWBS checkpoint".to_string())).transpose())
}

/// Atomically replace the single durable checkpoint. Call this only after the
/// corresponding wallet file has successfully been written.
pub fn store(data_dir: &str, height: u64) -> Result<(), String> {
    let conn = open(data_dir)?;
    let tx = conn.unchecked_transaction()
        .map_err(|e| format!("cannot begin AWBS checkpoint transaction: {}", e))?;
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|e| format!("clock error: {}", e))?
        .as_secs() as i64;
    tx.execute(
        "INSERT INTO checkpoints(id,height,updated_at) VALUES(1,?1,?2)
         ON CONFLICT(id) DO UPDATE SET height=excluded.height, updated_at=excluded.updated_at",
        params![i64::try_from(height).map_err(|_| "checkpoint height exceeds i64".to_string())?, now],
    ).map_err(|e| format!("cannot write AWBS checkpoint: {}", e))?;
    tx.commit().map_err(|e| format!("cannot commit AWBS checkpoint: {}", e))
}
