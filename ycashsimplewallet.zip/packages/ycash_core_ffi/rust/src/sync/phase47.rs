//! Phase 47: regtest scanner fixture and authenticated-storage bridge.
//!
//! This phase deliberately accepts only bytes exported from a real Ycash regtest
//! compact-block stream. It does not manufacture ciphertext, notes, or witnesses.

use crate::sync::phase43::{CompactBlockEnvelope, DecodedCompactBlock};

#[derive(Debug, thiserror::Error)]
pub enum Phase47Error {
    #[error("fixture height does not match transport envelope")]
    HeightMismatch,
    #[error("fixture block hash does not match transport envelope")]
    HashMismatch,
    #[error("fixture height exceeds the wallet compact-block height range")]
    HeightOutOfRange,
    #[error("fixture is empty")]
    EmptyFixture,
}

/// A fixture captured from a Ycash regtest lightwallet/compact-block endpoint.
/// `encoded` must be the generated CompactBlock protobuf bytes exactly as received.
#[derive(Debug, Clone)]
pub struct RegtestCompactBlockFixture {
    pub height: u64,
    pub block_hash: [u8; 32],
    pub prev_hash: [u8; 32],
    pub encoded: Vec<u8>,
}

impl RegtestCompactBlockFixture {
    pub fn into_envelope(self) -> Result<CompactBlockEnvelope, Phase47Error> {
        if self.encoded.is_empty() {
            return Err(Phase47Error::EmptyFixture);
        }
        Ok(CompactBlockEnvelope {
            height: u32::try_from(self.height).map_err(|_| Phase47Error::HeightOutOfRange)?,
            block_hash: self.block_hash,
            prev_hash: self.prev_hash,
            encoded: self.encoded,
        })
    }
}

/// Checks scanner output is associated with the same authenticated fixture before
/// handing it to the existing Phase 42 atomic ingestion path.
pub fn verify_fixture_binding(
    fixture: &RegtestCompactBlockFixture,
    envelope: &CompactBlockEnvelope,
    decoded: DecodedCompactBlock,
) -> Result<DecodedCompactBlock, Phase47Error> {
    if fixture.height != u64::from(envelope.height) { return Err(Phase47Error::HeightMismatch); }
    if fixture.block_hash != envelope.block_hash { return Err(Phase47Error::HashMismatch); }
    Ok(decoded)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_empty_fixture() {
        let f = RegtestCompactBlockFixture { height: 1, block_hash: [1;32], prev_hash: [0;32], encoded: vec![] };
        assert!(matches!(f.into_envelope(), Err(Phase47Error::EmptyFixture)));
    }
}
