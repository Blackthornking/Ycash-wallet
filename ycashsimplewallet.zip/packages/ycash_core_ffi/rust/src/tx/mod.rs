//! Transaction planning and production spending boundaries.
//!
//! Planning is always separated from cryptographic proving/signing. This prevents
//! the UI from treating a plan as a spendable network transaction.

#[derive(Debug, Clone)]
pub struct TransactionPlan {
    pub recipient: String,
    pub amount: u64,
    pub memo: Option<String>,
}

pub mod nullifier_migration;
pub mod production;
pub mod phase36;

/// Authenticated Sapling data required before any spend can be constructed.
/// Secrets are represented by opaque backend-owned handles rather than copied
/// into UI-facing transaction plans.
#[derive(Debug, Clone)]
pub struct SpendContext {
    pub network: YcashNetwork,
    pub selected_notes: Vec<AuthenticatedNote>,
    pub change_address: String,
    pub proving_params: ProvingParameters,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum YcashNetwork { Mainnet, Testnet, Regtest }

#[derive(Debug, Clone)]
pub struct AuthenticatedNote {
    pub note_commitment: [u8; 32],
    pub value: u64,
    pub position: u64,
    pub anchor: [u8; 32],
    pub witness: MerkleWitness,
    pub spending_key_handle: String,
}

#[derive(Debug, Clone)]
pub struct MerkleWitness { pub auth_path: Vec<[u8; 32]> }

#[derive(Debug, Clone)]
pub struct ProvingParameters {
    pub spend_params_path: String,
    pub output_params_path: String,
}
pub mod phase37;

pub mod phase38;

pub mod phase39;

pub mod phase40;

/// Phase 41 exact scanner payload. This stores the note plaintext components and
/// the complete Merkle authentication path, including direction bits, so a later
/// upstream-type adapter does not have to guess any consensus-critical data.
#[derive(Debug, Clone)]
pub struct SaplingNoteMaterial {
    pub diversifier: [u8; 11],
    pub pk_d: [u8; 32],
    pub rcm: [u8; 32],
}

#[derive(Debug, Clone)]
pub struct MerkleWitnessStep {
    pub sibling: [u8; 32],
    pub is_right: bool,
}

pub mod phase41;

pub mod phase51;
