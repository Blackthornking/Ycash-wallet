//! Ycash-specific nullifier migration policy.
//!
//! Wallets restored from pre-fork Sapling keys can optionally migrate funds to
//! a fresh wallet-owned Sapling address before external spending.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MigrationPlan {
    pub source_address: String,
    pub destination_address: String,
    pub note_count: usize,
    pub requires_confirmation: bool,
}

pub fn requires_user_confirmation(plan: &MigrationPlan) -> bool {
    plan.requires_confirmation && plan.note_count > 0
}
