//! Production gate for Phase 18.
use crate::upstream::{BackendCapability, SaplingBackend, require_ycash_verified};

pub fn allow_read_only_backend<B: SaplingBackend>(backend: &B) -> anyhow::Result<()> {
    require_ycash_verified(backend)?;
    anyhow::ensure!(backend.supports(BackendCapability::KeyDerivation), "missing key derivation");
    anyhow::ensure!(backend.supports(BackendCapability::SaplingAddress), "missing Sapling address support");
    anyhow::ensure!(backend.supports(BackendCapability::TrialDecrypt), "missing trial decryption");
    Ok(())
}

pub fn allow_spending_backend<B: SaplingBackend>(backend: &B) -> anyhow::Result<()> {
    allow_read_only_backend(backend)?;
    anyhow::ensure!(backend.supports(BackendCapability::NoteDetection), "missing note detection");
    anyhow::ensure!(backend.supports(BackendCapability::Spend), "spending is not verified");
    Ok(())
}
