//! Ycash Sapling integration boundary.
//!
//! This module deliberately does not implement Sapling cryptography itself.
//! Production implementations must be wired to the Ycash Foundation-maintained
//! Sapling/librustzcash fork at a reviewed commit and validated against Ycash.

use crate::network::YcashMainnet;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SaplingAddress(pub String);

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SaplingImportRequest {
    pub account: u32,
    pub source: SaplingKeySource,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SaplingKeySource {
    SpendingKey(String),
    ViewingKey(String),
    MnemonicDerived,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SaplingCapabilities {
    pub receive: bool,
    pub scan: bool,
    pub spend: bool,
}

pub trait SaplingBackend: Send + Sync {
    fn network(&self) -> YcashMainnet;
    fn capabilities(&self) -> SaplingCapabilities;
    fn derive_address(&self, account: u32) -> anyhow::Result<SaplingAddress>;
}

pub mod vectors;
