use serde::{Deserialize, Serialize};

/// Canonical Ycash mainnet constants must be verified against the Ycash node
/// source and covered by integration tests before transaction signing is enabled.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkConfig {
    pub name: &'static str,
    pub sapling_hrp: &'static str,
    pub transparent_p2pkh_prefix: [u8; 2],
    pub transparent_p2sh_prefix: [u8; 2],
    pub sapling_activation_height: u32,
    pub ycash_activation_height: u32,
    pub blossom_activation_height: u32,
    pub heartwood_activation_height: u32,
    pub canopy_activation_height: u32,
    pub message_start: [u8; 4],
    pub default_port: u16,
}

pub struct YcashMainnet;

impl YcashMainnet {
    pub fn config() -> NetworkConfig {
        NetworkConfig {
            name: "ycash-mainnet",
            sapling_hrp: "ys",
            transparent_p2pkh_prefix: [0x1c, 0x28],
            transparent_p2sh_prefix: [0x1c, 0x2c],
            sapling_activation_height: 419_200,
            ycash_activation_height: 570_000,
            blossom_activation_height: 1_100_000,
            heartwood_activation_height: 1_100_003,
            canopy_activation_height: 1_100_006,
            message_start: [0x24, 0xe9, 0x27, 0x64],
            default_port: 8333,
        }
    }
}
