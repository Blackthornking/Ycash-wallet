#[test]
fn core_remains_sapling_only() {
    assert!(ycash_core::backend::orchard_is_not_part_of_core());
}

#[test]
fn pinned_upstreams_are_not_floating() {
    for pin in ycash_core::integration::phase20_lock::all_pins() {
        assert!(!pin.revision.is_empty());
        assert_ne!(pin.revision, "main");
        assert_ne!(pin.revision, "master");
    }
}
