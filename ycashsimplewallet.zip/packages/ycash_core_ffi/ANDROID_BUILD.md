# Android native build

The Flutter app loads `libycash_core.so` with `dart:ffi`.

`android/app/build.gradle.kts` runs `cargo ndk` before Android `preBuild` and
places ABI-specific shared libraries in `android/app/src/main/jniLibs`.

Required build tools:

- Rust stable
- Android NDK (installed by the Flutter Android toolchain)
- `cargo install cargo-ndk --locked`
- Rust Android targets: arm64, armv7, x86_64
- `protoc` for the existing tonic/protobuf build script

The Rust ABI currently supports only mnemonic wallet create/restore/export and
wipe. All address, sync and spending methods remain fail-closed until Ycash
compatibility validation is complete.
