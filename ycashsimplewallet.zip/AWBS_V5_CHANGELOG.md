# AWBS V5

- Fixed V4 prefetch range-accounting bug by storing start/end heights with every queued fetch.
- Removed shared `queued_end_height` state so one queued range can never inherit another range's bounds.
- Preserved ordered wallet commits and bounded prefetch depth (8).
- Added V5 live AWBS telemetry to native sync status: last batch time, blocks/sec, bytes downloaded, next batch size, worker count, and prefetch depth.
- Surfaced AWBS telemetry directly on the wallet home screen.
- Standardized all wallet endpoint selection on `https://lite.ycash.xyz:9067`.
- Increased default scanner worker count from 4 to 8; AWBS remains bounded and adaptive.
- Retained the 2,000-block starting batch and 10,000-block hard maximum.

Build note: this environment does not contain Flutter/Dart or Cargo toolchains, so a native Android/Flutter compile could not be executed here. The source tree and generated V5 archive should be built with the project's normal Flutter/Android toolchain before device deployment.
## V5.1 — parallel crypto scan pipeline

- Trial decryption is now partitioned into bounded 256-output groups and dispatched to the existing shared scanner `ThreadPool`.
- Results are tagged with their original output positions and deterministically reassembled before any wallet/tree mutation.
- Commitment-tree and witness updates remain strictly sequential in transaction/output order, preserving wallet state semantics.
- Non-canonical compact ciphertexts retain the legacy decryption fallback.
- Added a regression check comparing parallel and sequential match results over 512 outputs.
- This is an architectural throughput optimization; it does not change transaction, note, key, or signature serialization.

