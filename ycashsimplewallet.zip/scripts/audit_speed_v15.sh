#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
LW="$ROOT/packages/ycash_core_ffi/rust/vendor/yecshell-lib/src/lightwallet.rs"
GC="$ROOT/packages/ycash_core_ffi/rust/vendor/yecshell-lib/src/grpcconnector.rs"
PS="$ROOT/packages/ycash_core_ffi/rust/src/sync/proofskip.rs"
for needle in \
  'prepare_cross_block_matches' \
  'take_cross_block_matches' \
  'materialize_batch_note' \
  'if outputs.len() < 16' \
  'nf_index: HashMap<[u8; 4]' \
  'std::mem::take(&mut tx.spends)' \
  'scan_compact_block_with_pool' \
  'CrossBlockScratch'; do
  grep -F "$needle" "$LW" >/dev/null
done
grep -F 'FULL_TX_RPC_CONCURRENCY' "$GC" >/dev/null
grep -F 'join_all' "$GC" >/dev/null
grep -F 'FULL_TX_RUNTIME' "$GC" >/dev/null
grep -F 'PROOFSKIP_ENABLED: bool = false' "$PS" >/dev/null
echo 'Yodl V15 source optimization audit: PASS'
