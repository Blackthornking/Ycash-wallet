# Yodl Native Compatibility Layer Audit

## Status

The old `yecshell` crate/application dependency has been replaced by an
internally owned `ycash-compat-engine` crate under
`packages/ycash_core_ffi/rust/vendor/ycash-compat-engine`.

The production scanner remains the Ycash-native scanner. The compatibility
engine exists only at the application/API boundary for wallet lifecycle,
serialization, sync orchestration, transaction planning and broadcast.

## Deliberate compatibility choices

- Existing `ycash_yecshell_*` C ABI symbols are retained so existing Flutter
  code does not break. These are ABI names only.
- The existing on-disk `yecshell_wallet.dat` filename is retained so existing
  wallets are not silently orphaned.
- The old Rust package name `zecwalletlitelib` is gone; the internal package is
  `ycash_compat_engine`.

## Remaining dependency

`libyec` is still vendored and used by the compatibility engine for the
consensus-sensitive Sapling/protocol types required by the current wallet
format and transaction path. It is treated as a pinned protocol compatibility
stack, not as the wallet application's architecture.

Removing/replacing `libyec` itself is a separate migration because it requires
proving byte-for-byte wallet serialization, address derivation, transaction
construction, and consensus compatibility against Ycash vectors before the
old implementation can safely disappear.

## Verification limitation

This environment does not contain `cargo`/`rustc`, so a native Rust build and
runtime test could not be executed here. The source/package references were
rewritten consistently and stale `yecshell` Rust crate/package references were
removed from the dependency graph; ABI symbol names intentionally remain.
